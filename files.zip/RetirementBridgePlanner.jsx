import React, { useState, useEffect, useMemo } from "react";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  BarChart, Bar, Legend, ReferenceLine, Area, AreaChart, ComposedChart,
} from "recharts";

/* =================================================================== */
/*  עיצוב                                                               */
/* =================================================================== */
const STYLES = `
@import url('https://fonts.googleapis.com/css2?family=Frank+Ruhl+Libre:wght@500;700;900&family=Assistant:wght@400;500;600;700;800&display=swap');
:root{
  --ink:#15302b;--ink-2:#1d3f38;--paper:#f3f6f4;--card:#fff;--line:#e3e8e4;
  --muted:#5e6f69;--brass:#b0852f;--brass-soft:#e8d8b4;
  --green:#2e7d5b;--amber:#bd8814;--red:#bf473b;
  --green-bg:#e6f1ec;--amber-bg:#f7eed8;--red-bg:#f7e4e1;--blue-bg:#e8eef2;--blue:#3f6a86;
}
*{box-sizing:border-box}
.rbp{font-family:'Assistant',system-ui,sans-serif;color:var(--ink);background:var(--paper);min-height:100vh;direction:rtl;line-height:1.5}
.rbp .serif{font-family:'Frank Ruhl Libre',Georgia,serif}
.wrap{max-width:1120px;margin:0 auto;padding:0 18px 64px}
.hero{background:var(--ink);color:#f6f4ec;border-radius:0 0 26px 26px;padding:26px 22px 30px;box-shadow:0 18px 40px -28px rgba(21,48,43,.6)}
.hero .kicker{font-size:13px;letter-spacing:.14em;color:var(--brass-soft);text-transform:uppercase;font-weight:700;margin:0 0 4px}
.hero h1{font-weight:900;font-size:30px;margin:0 0 2px}
.hero .sub{color:#c8d2cd;font-size:15px;max-width:64ch;margin:6px 0 0}
.verdict-row{display:flex;flex-wrap:wrap;gap:18px;align-items:center;margin-top:20px}
.verdict{display:flex;align-items:center;gap:12px}
.dot{width:14px;height:14px;border-radius:50%;box-shadow:0 0 0 4px rgba(255,255,255,.12)}
.verdict .lbl{font-size:13px;color:#aebbb5}
.verdict .val{font-family:'Frank Ruhl Libre',serif;font-weight:700;font-size:22px}
.vfig{margin-inline-start:auto;text-align:center}
.vfig .n{font-size:26px;font-weight:800;font-family:'Frank Ruhl Libre',serif}
.vfig .c{font-size:12px;color:#aebbb5;letter-spacing:.05em}
.bridge{margin-top:18px;background:#11271f;border-radius:16px;padding:8px 10px 4px}
.tabs{display:flex;gap:6px;margin:22px 0 20px;background:#fff;padding:6px;border-radius:14px;border:1px solid var(--line);box-shadow:0 6px 18px -16px rgba(21,48,43,.5);flex-wrap:wrap}
.tab{flex:1;min-width:104px;border:0;background:transparent;font-family:inherit;font-size:14.5px;font-weight:700;color:var(--muted);padding:11px 8px;border-radius:9px;cursor:pointer;transition:.15s}
.tab[aria-selected="true"]{background:var(--ink);color:#f6f4ec}
.tab:focus-visible{outline:2px solid var(--brass);outline-offset:2px}
.grid{display:grid;gap:16px}
@media(min-width:760px){.cols-2{grid-template-columns:1fr 1fr}.cols-3{grid-template-columns:1fr 1fr 1fr}}
.card{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:18px;box-shadow:0 8px 24px -22px rgba(21,48,43,.5)}
.card h3{margin:0 0 14px;font-size:13px;letter-spacing:.08em;text-transform:uppercase;color:var(--brass);font-weight:800;display:flex;align-items:center;gap:8px;flex-wrap:wrap}
.card h3 .num{font-family:'Frank Ruhl Libre',serif;color:var(--ink);font-size:15px;background:var(--paper);border:1px solid var(--line);border-radius:7px;width:24px;height:24px;display:grid;place-items:center}
.field{margin-bottom:14px}.field:last-child{margin-bottom:0}
.field label{display:block;font-size:14px;font-weight:600;margin-bottom:5px}
.field .hint{font-size:12px;color:var(--muted);margin-top:4px}
.inp{display:flex;align-items:center;border:1px solid var(--line);border-radius:10px;background:#fcfdfc;overflow:hidden}
.inp:focus-within{border-color:var(--brass);box-shadow:0 0 0 3px rgba(176,133,47,.15)}
.inp input{flex:1;border:0;background:transparent;font-family:inherit;font-size:16px;font-weight:700;color:var(--ink);padding:10px 12px;width:100%;text-align:right}
.inp input:focus{outline:none}
.inp .suf{padding:0 12px;color:var(--muted);font-size:14px;font-weight:600;border-inline-start:1px solid var(--line);align-self:stretch;display:flex;align-items:center;background:var(--paper)}
.toggle{display:flex;align-items:center;justify-content:space-between;gap:10px;border:1px solid var(--line);border-radius:10px;padding:9px 12px;background:#fcfdfc}
.tg-btn{position:relative;width:46px;height:26px;border-radius:20px;border:0;cursor:pointer;background:#cdd6d1;transition:.18s;flex-shrink:0}
.tg-btn[data-on="true"]{background:var(--green)}
.tg-btn span{position:absolute;top:3px;inset-inline-end:3px;width:20px;height:20px;border-radius:50%;background:#fff;transition:.18s;box-shadow:0 1px 3px rgba(0,0,0,.25)}
.tg-btn[data-on="true"] span{inset-inline-end:23px}
.metric{border:1px solid var(--line);border-radius:13px;padding:13px 14px;background:#fff;display:flex;flex-direction:column;gap:3px}
.metric .mlbl{font-size:13px;color:var(--muted);font-weight:600}
.metric .mval{font-size:23px;font-weight:800;font-family:'Frank Ruhl Libre',serif}
.metric .mnote{font-size:12px;color:var(--muted)}
.metric.s-green{border-color:#b8d8c8;background:var(--green-bg)}.s-green .mval{color:var(--green)}
.metric.s-amber{border-color:#ecd9a6;background:var(--amber-bg)}.s-amber .mval{color:var(--amber)}
.metric.s-red{border-color:#eec3bd;background:var(--red-bg)}.s-red .mval{color:var(--red)}
.chip{font-size:11px;font-weight:800;letter-spacing:.04em;padding:2px 8px;border-radius:20px;align-self:flex-start}
.chip.s-green{background:#cde7da;color:#1c5b41}.chip.s-amber{background:#f0e1b3;color:#7a5908}.chip.s-red{background:#f3cdc6;color:#8a2c22}
.alert{display:flex;gap:11px;padding:13px 14px;border-radius:12px;border:1px solid;margin-bottom:10px;align-items:flex-start}
.alert .ai{font-size:18px;line-height:1.2;margin-top:1px}
.alert .at{font-weight:800;font-size:15px;margin:0 0 2px}
.alert .ax{font-size:13.5px;color:#3f4d48;margin:0}
.alert.l-red{background:var(--red-bg);border-color:#eec3bd}
.alert.l-amber{background:var(--amber-bg);border-color:#ecd9a6}
.alert.l-info{background:#eaf0ee;border-color:#cfdcd6}
.alert.l-good{background:var(--green-bg);border-color:#b8d8c8}
.tbl{width:100%;border-collapse:collapse;font-size:13px}
.tbl th{font-size:11.5px;letter-spacing:.03em;color:var(--muted);text-align:right;padding:8px 8px;border-bottom:2px solid var(--line);font-weight:700;white-space:nowrap}
.tbl td{padding:8px 8px;border-bottom:1px solid var(--line);font-weight:600;white-space:nowrap}
.tbl tr:last-child td{border-bottom:0}
.tbl .hl td{background:var(--amber-bg)}
.tbl .dead td{background:var(--red-bg);font-weight:800}
.scrollx{overflow-x:auto;-webkit-overflow-scrolling:touch}
.btn{font-family:inherit;font-weight:700;font-size:15px;border-radius:11px;padding:11px 18px;cursor:pointer;border:1px solid var(--line);background:#fff;color:var(--ink);transition:.15s}
.btn:hover{border-color:var(--brass)}
.btn.primary{background:var(--ink);color:#f6f4ec;border-color:var(--ink)}
.btn.primary:hover{background:var(--ink-2)}
.btn.danger{color:var(--red);border-color:#eec3bd}
.btn:focus-visible{outline:2px solid var(--brass);outline-offset:2px}
.row{display:flex;flex-wrap:wrap;gap:10px;align-items:center}
.thesis{font-family:'Frank Ruhl Libre',serif;font-size:16px;color:var(--ink-2);padding:12px 14px;margin:0 0 12px;background:#fff;border-radius:0 12px 12px 0;border:1px solid var(--line);border-inline-start:3px solid var(--brass)}
.empty{color:var(--muted);font-size:14px;text-align:center;padding:26px 10px}
.foot{font-size:12px;color:var(--muted);margin-top:8px;line-height:1.6}
.pill{display:inline-block;font-size:11px;font-weight:700;padding:2px 9px;border-radius:20px;background:var(--blue-bg);color:var(--blue)}
@media(prefers-reduced-motion:reduce){*{transition:none!important}}
`;

/* =================================================================== */
/*  קבועי 2026 (מאומתים מול כל-זכות / ביטוח לאומי / רשות המסים)         */
/* =================================================================== */
const TAX2026 = {
  cgtFlat: 0.25,
  over60Ceiling: 193800,
  over60Bands: [
    { upTo: 84120, rate: 0.10 },
    { upTo: 120720, rate: 0.14 },
    { upTo: 193800, rate: 0.20 },
    { upTo: Infinity, rate: 0.25 },
  ],
  oldAgeAllowanceSingle: 1838,
};

const ils = new Intl.NumberFormat("he-IL", { style: "currency", currency: "ILS", maximumFractionDigits: 0 });
const fmt = (n) => (isFinite(n) ? ils.format(Math.round(n)) : "—");
const fmtK = (n) => (isFinite(n) ? "₪" + Math.round(n).toLocaleString("he-IL") : "—");
const pct = (n) => (isFinite(n) ? (n * 100).toFixed(1) + "%" : "—");
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

/* מס רווחי הון על רווח G לאדם בגיל age, שמעליו נערמת הכנסה אחרת OI */
function cgtOnGain(gain, age, otherIncome) {
  if (gain <= 0) return 0;
  if (age < 60) return gain * TAX2026.cgtFlat;
  let hi = otherIncome + gain, tax = 0, prev = 0;
  for (const b of TAX2026.over60Bands) {
    const seg = Math.max(0, Math.min(hi, b.upTo) - Math.max(otherIncome, prev));
    if (seg > 0) tax += seg * b.rate;
    prev = b.upTo;
    if (b.upTo >= hi) break;
  }
  return tax;
}

/* =================================================================== */
/*  ברירות מחדל (נתוני דוגמה — להחליף בנתונים שלך)                      */
/* =================================================================== */
const PERSON = (over) => ({
  name: "בן/בת זוג", currentAge: 55, retirementAge: 55,
  portfolio: 1000000, portfolioTaxOnSale: 75000,
  studyFund: 250000, studyFundLiquidAge: 60,
  rsuVestedGross: 0, rsuUnvestedExpected: 0, rsuTaxRate: 25,
  pensionNetMonthly: 7000, pensionStartAge: 67,
  allowanceMonthly: 1838, allowanceStartAge: 70,
  severance: 0, ...over,
});

// נכסי גשר מהדוח (יוני 2026) + שדות פתוחים להשלמה
// קצבה צפויה משותפת: 57,722 ש״ח/חודש (ניר + מאיה יחד) — מוזנת כנטו כולל שניהם
// ביטוחי חיים/חיסכון = קצבתיים — לא נכסי גשר
// קופת גמל מיטב 2,067,252 = לילדים — לא בתחשיב
const DEFAULTS = {
  targetMonthly: 50000, passiveMonthly: 20000, passiveIndexed: true, inflation: 3,
  cash: 0, safetyBuffer: 15, stressMarketDrop: 25, stressPassiveFactor: 60,
  planStartYears: 1, planningAge: 95, expReturn: 5, cashReturn: 2,
  cashBucketMonths: 18, refillCadence: 12,
  rsuSpreadYears: 4, rsuPreferAfter60: true,
  // הכנסות/נכסים נוספים (שדה פתוח עם הערה)
  extraItems: [
    { id: 1, label: "שכירות נדל"ן (נטו/חודש)", amount: 20000, type: "passive_monthly", note: "הכנסה פסיבית — כבר נכללת בשדה הכנסה פסיבית" },
    { id: 2, label: "החזר השקעת נדל"ן (צפי)", amount: 595000, type: "one_time_future", note: "אמור לכסות הלוואה ₪595,000 על קופת גמל מיטב" },
    { id: 3, label: "תיק השקעות נוסף", amount: 0, type: "portfolio", note: "להזין שווי + מס" },
  ],
  people: [
    PERSON({ name: "ניר", currentAge: 0, retirementAge: 0,
      // קה״ש: 68,882+282,829+195,832+305,833 = 853,376
      studyFund: 853376, studyFundLiquidAge: 60,
      // גמל More: 87,862 + חיסכון טהור הפניקס: 1,335,309
      portfolio: 87862 + 1335309, portfolioTaxOnSale: 0,
      // RSU — להזין ידנית
      rsuVestedGross: 0, rsuUnvestedExpected: 0, rsuTaxRate: 25,
      // קצבה — מוזנת כחצי מהקצבה המשותפת (57,722/2) כאומדן; לעדכן לפי פירוט
      pensionNetMonthly: 28861, pensionStartAge: 67,
      allowanceMonthly: 1838, allowanceStartAge: 70,
      severance: 1158874,
    }),
    PERSON({ name: "מאיה", currentAge: 0, retirementAge: 0,
      // קה״ש: 79,533+61,045+37,054+33,681+67,210+106,904+8,735+129,662+284,881 = 808,705
      studyFund: 808705, studyFundLiquidAge: 60,
      // גמל More: 324,819 + גמל להשקעה: 134,670
      portfolio: 324819 + 134670, portfolioTaxOnSale: 0,
      rsuVestedGross: 0, rsuUnvestedExpected: 0, rsuTaxRate: 0,
      // קצבה — חצי שני; לעדכן
      pensionNetMonthly: 28861, pensionStartAge: 67,
      allowanceMonthly: 1838, allowanceStartAge: 70,
      severance: 782089,
    }),
  ],
};

/* =================================================================== */
/*  מנוע החישוב                                                         */
/* =================================================================== */
function compute(H) {
  const infl = (H.inflation || 0) / 100;
  const buffer = (H.safetyBuffer || 0) / 100;
  const ret = (H.expReturn || 0) / 100;
  const cashRet = (H.cashReturn || 0) / 100;
  const P = H.people;
  const NOW = 2026;

  const rsuVestedNet = (p) => (p.rsuVestedGross || 0) * (1 - (p.rsuTaxRate || 0) / 100);
  const totVestedNet = P.reduce((s, p) => s + rsuVestedNet(p), 0);
  const totPortfolio = P.reduce((s, p) => s + (p.portfolio || 0), 0);
  const totStudy = P.reduce((s, p) => s + (p.studyFund || 0), 0);
  const liquidNet = (H.cash || 0) + totPortfolio + totVestedNet;
  const monthlyGap = (H.targetMonthly || 0) - (H.passiveMonthly || 0);
  const annualGap = monthlyGap * 12;

  const tStart = Math.max(0, H.planStartYears || 0);
  const horizon = clamp(Math.max(...P.map((p) => (H.planningAge || 95) - (p.currentAge || 0))), 1, 50);
  let firstLayerT = horizon;
  P.forEach((p) => {
    const pT = (p.pensionStartAge || 200) - (p.currentAge || 0);
    const aT = (p.allowanceStartAge || 200) - (p.currentAge || 0);
    firstLayerT = Math.min(firstLayerT, Math.max(pT, tStart), Math.max(aT, tStart));
  });
  const bridgeYears = Math.max(0, Math.round(firstLayerT - tStart));

  /* סימולציה שנתית */
  let cashBal = H.cash || 0;
  const ports = P.map((p) => ({ bal: p.portfolio || 0, taxFrac: (p.portfolio || 0) > 0 ? (p.portfolioTaxOnSale || 0) / (p.portfolio || 1) : 0 }));
  const studies = P.map((p) => ({ bal: p.studyFund || 0, liqAge: p.studyFundLiquidAge || 60 }));
  const rows = [];
  let depletedAge = null;
  let bridgeRequired = 0;

  const drawPort = (need, ages, passive, pensions, allowances) => {
    let fromPort = 0, tax = 0;
    for (let pass = 0; pass < 2 && need > 0.5; pass++) {
      const totBal = ports.reduce((s, x) => s + x.bal, 0);
      if (totBal <= 0) break;
      ports.forEach((x, k) => {
        if (need <= 0.5 || x.bal <= 0) return;
        const share = pass === 0 ? x.bal / totBal : 1;
        const want = need * share;
        // taxFrac = יחס המס הצפוי ממכירה (מס/שווי), מבוסס על "מס משוער במימוש" שהוזן
        const gross = Math.min(x.bal, want / (1 - x.taxFrac));
        const tx = gross * x.taxFrac;
        const net = gross - tx;
        x.bal -= gross; fromPort += net; tax += tx; need -= net;
      });
    }
    return { fromPort, tax, need };
  };

  for (let t = tStart; t <= horizon; t++) {
    const ages = P.map((p) => (p.currentAge || 0) + t);
    ports.forEach((x) => (x.bal *= 1 + ret));
    cashBal *= 1 + cashRet;
    const expenses = (H.targetMonthly || 0) * 12 * Math.pow(1 + infl, t);
    const passive = (H.passiveMonthly || 0) * 12 * (H.passiveIndexed ? Math.pow(1 + infl, t) : 1);
    const pensions = P.map((p, k) => (ages[k] >= (p.pensionStartAge || 200) ? (p.pensionNetMonthly || 0) * 12 : 0));
    const allowances = P.map((p, k) => (ages[k] >= (p.allowanceStartAge || 200) ? (p.allowanceMonthly || 0) * 12 : 0));
    const pensionTot = pensions.reduce((s, x) => s + x, 0);
    const allowTot = allowances.reduce((s, x) => s + x, 0);
    const nonPort = passive + pensionTot + allowTot;
    const gap = Math.max(0, expenses - nonPort);
    if (t < tStart + bridgeYears) bridgeRequired += gap;

    let need = gap, fromCash = 0, fromStudy = 0;
    const c = Math.min(cashBal, need); cashBal -= c; need -= c; fromCash = c;
    studies.forEach((s, k) => {
      if (need <= 0.5) return;
      if (ages[k] >= s.liqAge && s.bal > 0) { const dd = Math.min(s.bal, need); s.bal -= dd; need -= dd; fromStudy += dd; }
    });
    const { fromPort, tax, need: left } = drawPort(need, ages, passive, pensions, allowances);
    const portEnd = ports.reduce((s, x) => s + x.bal, 0);
    if (left > 0.5 && depletedAge === null) depletedAge = Math.min(...ages);

    rows.push({
      t, year: NOW + t, ageLabel: ages.join(" / "), minAge: Math.min(...ages),
      expenses, passive, pension: pensionTot, allowance: allowTot, gap,
      fromCash, fromStudy, fromPort, tax, portEnd, cashEnd: cashBal,
      shortfall: left > 0.5 ? left : 0,
      phase: allowTot > 0 ? "ד" : pensionTot > 0 ? "ב/ג" : "א",
    });
  }

  const bridgeReqBuf = bridgeRequired * (1 + buffer);
  const bridgeRatio = bridgeReqBuf > 0 ? liquidNet / bridgeReqBuf : (liquidNet > 0 ? 99 : 0);
  const surplus = liquidNet - bridgeReqBuf;
  const status = bridgeYears === 0 ? "decision" : bridgeRatio >= 1.25 ? "green" : bridgeRatio >= 1 ? "amber" : "red";

  const withdrawalRate = liquidNet > 0 ? annualGap / liquidNet : 0;
  const passiveCoverage = (H.targetMonthly || 0) > 0 ? (H.passiveMonthly || 0) / (H.targetMonthly || 0) : 0;
  const rsuConc = liquidNet > 0 ? totVestedNet / liquidNet : 0;
  const cashMonths = monthlyGap > 0 ? (H.cash || 0) / monthlyGap : Infinity;

  const sF = (H.stressPassiveFactor || 100) / 100, sD = (H.stressMarketDrop || 0) / 100;
  let reqStress = 0;
  for (let t = tStart; t < tStart + bridgeYears; t++) {
    const exp = (H.targetMonthly || 0) * 12 * Math.pow(1 + infl, t);
    const pas = (H.passiveMonthly || 0) * sF * 12 * (H.passiveIndexed ? Math.pow(1 + infl, t) : 1);
    reqStress += Math.max(0, exp - pas);
  }
  reqStress *= 1 + buffer;
  const availStress = (H.cash || 0) + totPortfolio * (1 - sD) + totVestedNet * (1 - sD);
  const stressRatio = reqStress > 0 ? availStress / reqStress : (availStress > 0 ? 99 : 0);
  const resilient = stressRatio >= 1;

  /* תזרים חודשי */
  const draw = monthlyGap;
  const bucketTarget = draw * (H.cashBucketMonths || 0);
  let bucket = Math.min(H.cash || 0, bucketTarget || (H.cash || 0));
  const cashFlow = [];
  let refillTax = 0;
  const gAvg = totPortfolio > 0 ? P.reduce((s, p) => s + (p.portfolioTaxOnSale || 0), 0) / totPortfolio : 0;
  for (let m = 1; m <= 24; m++) {
    bucket -= draw;
    let refill = 0;
    if ((H.refillCadence || 12) > 0 && m % (H.refillCadence || 12) === 0) {
      refill = Math.max(0, bucketTarget - bucket); bucket += refill;
      refillTax += refill * gAvg * 0.25;
    }
    cashFlow.push({ m, bucket: Math.round(bucket), refill: Math.round(refill), low: bucket < draw });
  }

  /* לוח מימוש RSU */
  const rsuPlans = P.filter((p) => (p.rsuVestedGross || 0) > 0).map((p) => {
    const n = Math.max(1, H.rsuSpreadYears || 1);
    const startT = H.rsuPreferAfter60 ? Math.max(tStart, 60 - (p.currentAge || 0)) : tStart;
    const tranche = (p.rsuVestedGross || 0) / n;
    const gainPct = 0.7;
    const oi = (H.passiveMonthly || 0) / P.length * 12;
    const sched = [];
    for (let k = 0; k < n; k++) {
      const tt = startT + k, age = (p.currentAge || 0) + tt;
      const tax = cgtOnGain(tranche * gainPct, age, oi);
      sched.push({ year: NOW + tt, age, amount: tranche, tax, rate: tax / (tranche * gainPct) });
    }
    const lumpAge = (p.currentAge || 0) + tStart;
    const lumpTax = cgtOnGain((p.rsuVestedGross || 0) * gainPct, lumpAge, oi);
    const spreadTax = sched.reduce((s, x) => s + x.tax, 0);
    return { name: p.name, sched, lumpTax, spreadTax, saving: lumpTax - spreadTax };
  });

  /* התרעות */
  const A = [];
  if (bridgeYears > 0 && bridgeRatio < 1) A.push({ level: "red", t: "חסר הון לגשר", x: `חסרים כ־${fmt(-surplus)} למימון הגשר עד שכבת ההכנסה הבאה (כולל כרית ${H.safetyBuffer}%).` });
  if (cashMonths < 12) A.push({ level: "red", t: "כרית נזילות לא מספקת", x: `כ־${isFinite(cashMonths) ? cashMonths.toFixed(0) : "∞"} חודשי פער במזומן. לא לפרוש לפני כרית של 12–24 חודשים.` });
  else if (cashMonths < 24) A.push({ level: "amber", t: "כרית נזילות בינונית", x: `כ־${cashMonths.toFixed(0)} חודשי פער. כדאי לכוון ל-24+ כדי לא למכור בירידות.` });
  if (rsuConc > 0.25) A.push({ level: "red", t: "ריכוזיות RSU גבוהה", x: `RSU שהבשיל = ${pct(rsuConc)} מההון הנזיל. לבנות מימוש מדורג (לשונית RSU).` });
  else if (rsuConc > 0.10) A.push({ level: "amber", t: "בדיקת מימוש RSU מדורג", x: `RSU = ${pct(rsuConc)} מההון הנזיל.` });
  if (depletedAge !== null) A.push({ level: "red", t: "התיק עלול להיגמר", x: `לפי ההנחות, ההון מסתיים סביב גיל ${depletedAge}. הקטיני הוצאה, הגדילי תשואה/כרית, או דחי פרישה.` });
  if (bridgeYears > 0 && !resilient) A.push({ level: "red", t: "לא שורד תרחיש לחץ", x: `בירידת שוק ${H.stressMarketDrop}% והכנסה פסיבית ב-${H.stressPassiveFactor}%, יחס הגשר ${pct(stressRatio)}.` });
  if (withdrawalRate > 0.05) A.push({ level: "amber", t: "שיעור משיכה גבוה", x: `${pct(withdrawalRate)} מהנכסים בשנה — לגשר קצוב ייתכן שסביר, אך תלוי בכניסת הקצבאות.` });
  P.forEach((p) => { if ((p.currentAge || 0) < 60) A.push({ level: "info", t: `הטבת מס 60+ עבור ${p.name}`, x: `מגיל 60, אם ההכנסה החייבת מתחת ל-${fmt(TAX2026.over60Ceiling)}, מס רווחי ההון יורד למדרגות 10/14/20%. כדאי לתזמן מימושים לשנים אלה.` }); });
  if (P.some((p) => (p.rsuVestedGross || 0) > 0 || (p.rsuUnvestedExpected || 0) > 0)) A.push({ level: "info", t: "יועץ מס לפני מימוש RSU", x: "מסלול 102 ורכיב הכנסת עבודה אפשרי — לאמת עם רו״ח לפני מכירה." });
  if (P.some((p) => (p.severance || 0) > 0)) A.push({ level: "info", t: "פיצויים — בדיקת רו״ח", x: "רצף קצבה/פיצויים משפיע על המס ועל הקצבה. לא נכלל בחישוב הגשר." });
  A.push({ level: "info", t: "קיבוע זכויות בגיל הזכאות", x: "החלטה כמעט בלתי הפיכה — לבדוק עם יועץ פרישה." });
  if (bridgeYears > 0 && bridgeRatio >= 1.25 && resilient && depletedAge === null && cashMonths >= 12)
    A.unshift({ level: "good", t: "הגשר אפשרי", x: `הנכסים מכסים ${pct(bridgeRatio)} מהגשר, התוכנית שורדת לחץ, וההון מחזיק עד גיל ${H.planningAge}.` });

  return {
    liquidNet, totPortfolio, totStudy, totVestedNet, monthlyGap, annualGap,
    bridgeYears, bridgeRequired, bridgeReqBuf, bridgeRatio, surplus, status,
    withdrawalRate, passiveCoverage, rsuConc, cashMonths, stressRatio, resilient,
    rows, depletedAge, cashFlow, refillTax, draw, bucketTarget, rsuPlans, alerts: A,
  };
}

/* =================================================================== */
/*  רכיבי UI                                                            */
/* =================================================================== */
function Money({ label, hint, value, onChange }) {
  return (
    <div className="field"><label>{label}</label>
      <div className="inp"><input type="number" inputMode="numeric" value={value} onChange={(e) => onChange(e.target.value === "" ? 0 : Number(e.target.value))} /><span className="suf">₪</span></div>
      <div className="hint">{hint || fmt(value)}</div>
    </div>
  );
}
function Num({ label, hint, value, onChange, suffix }) {
  return (
    <div className="field"><label>{label}</label>
      <div className="inp"><input type="number" inputMode="numeric" value={value} onChange={(e) => onChange(e.target.value === "" ? 0 : Number(e.target.value))} />{suffix && <span className="suf">{suffix}</span>}</div>
      {hint && <div className="hint">{hint}</div>}
    </div>
  );
}
function Txt({ label, value, onChange }) {
  return (<div className="field"><label>{label}</label><div className="inp"><input type="text" value={value} onChange={(e) => onChange(e.target.value)} /></div></div>);
}
function Toggle({ label, value, onChange }) {
  return (<div className="field"><div className="toggle"><span style={{ fontWeight: 600, fontSize: 14 }}>{label}</span>
    <button className="tg-btn" data-on={value} aria-pressed={value} onClick={() => onChange(!value)} aria-label={label}><span /></button></div></div>);
}
function Metric({ label, value, s, note }) {
  return (<div className={"metric s-" + s}><span className="mlbl">{label}</span><span className="mval">{value}</span>{note && <span className="mnote">{note}</span>}</div>);
}
const statusOf = (v, g, a) => (v >= g ? "green" : v >= a ? "amber" : "red");

function Bridge({ d }) {
  const deckY = 120, x0 = 90, x1 = 640;
  const fundedX = x0 + (x1 - x0) * clamp(d.bridgeRatio, 0, 1);
  const pillars = [x0, x0 + (x1 - x0) / 3, x0 + (2 * (x1 - x0)) / 3, x1];
  return (
    <svg viewBox="0 0 800 190" className="bridge" role="img" aria-label="גשר הפרישה">
      <line x1="40" y1="158" x2="760" y2="158" stroke="#27463b" strokeWidth="2" />
      {pillars.map((px, k) => <line key={k} x1={px} y1={deckY + 8} x2={px} y2="158" stroke="#3a5a4d" strokeWidth="6" strokeLinecap="round" />)}
      <rect x={x0 - 26} y={deckY - 6} width="26" height="74" rx="4" fill="#27463b" />
      <rect x={x1} y={deckY - 6} width="26" height="74" rx="4" fill="#27463b" />
      <rect x={x0} y={deckY} width={x1 - x0} height="14" rx="7" fill="#27463b" />
      <line x1={fundedX} y1={deckY - 6} x2={x1} y2={deckY - 6} stroke="#c4524a" strokeWidth="3" strokeDasharray="2 7" opacity="0.9" />
      <rect x={x0} y={deckY} width={Math.max(0, fundedX - x0)} height="14" rx="7" fill="#cdb06a" />
      <path d={`M ${x0} ${deckY} Q ${(x0 + x1) / 2} ${deckY + 60} ${x1} ${deckY}`} fill="none" stroke="#3a5a4d" strokeWidth="2" opacity="0.6" />
      <text x={x0 - 13} y="180" fill="#aebbb5" fontSize="13" textAnchor="middle" fontFamily="Assistant">תחילת פרישה</text>
      <text x={x1 + 13} y="180" fill="#e8d8b4" fontSize="13" textAnchor="middle" fontWeight="700" fontFamily="Assistant">שכבת הכנסה</text>
      <text x={(x0 + x1) / 2} y="96" fill="#f0ead8" fontSize="20" textAnchor="middle" fontWeight="700" fontFamily="Frank Ruhl Libre">גשר של {d.bridgeYears} שנים</text>
      <text x={(x0 + x1) / 2} y="44" fill="#aebbb5" fontSize="13" textAnchor="middle" fontFamily="Assistant">ממומן {pct(d.bridgeRatio)} מהיעד</text>
    </svg>
  );
}

const ST = {
  green: { lbl: "סטטוס הגשר", val: "אפשר לפרוש", color: "var(--green)" },
  amber: { lbl: "סטטוס הגשר", val: "אפשר עם התאמות", color: "var(--amber)" },
  red: { lbl: "סטטוס הגשר", val: "עוד לא מומלץ", color: "var(--red)" },
  decision: { lbl: "אין שלב גשר", val: "מסך החלטת קצבאות", color: "var(--brass)" },
};

/* =================================================================== */
export default function App() {
  const [H, setH] = useState(DEFAULTS);
  const [tab, setTab] = useState("dash");
  const [snaps, setSnaps] = useState([]);
  const [loaded, setLoaded] = useState(false);
  const hasStore = typeof window !== "undefined" && window.storage;
  const setHK = (k) => (v) => setH((p) => ({ ...p, [k]: v }));
  const setP = (idx, k) => (v) => setH((p) => ({ ...p, people: p.people.map((pp, i) => (i === idx ? { ...pp, [k]: v } : pp)) }));
  const d = useMemo(() => compute(H), [H]);

  useEffect(() => {
    (async () => {
      if (hasStore) {
        try { const r = await window.storage.get("rbp2_inputs"); if (r?.value) setH((p) => ({ ...DEFAULTS, ...JSON.parse(r.value) })); } catch (e) {}
        try { const s = await window.storage.get("rbp2_snaps"); if (s?.value) setSnaps(JSON.parse(s.value)); } catch (e) {}
      }
      setLoaded(true);
    })();
  }, []); // eslint-disable-line
  useEffect(() => { if (loaded && hasStore) { try { window.storage.set("rbp2_inputs", JSON.stringify(H)); } catch (e) {} } }, [H, loaded]); // eslint-disable-line

  const saveSnap = async () => {
    const snap = { id: Date.now(), date: new Date().toLocaleDateString("he-IL"), ratio: d.bridgeRatio, available: d.liquidNet, required: d.bridgeReqBuf, status: d.status, depleted: d.depletedAge };
    const next = [...snaps, snap].slice(-40); setSnaps(next);
    if (hasStore) { try { await window.storage.set("rbp2_snaps", JSON.stringify(next)); } catch (e) {} }
  };
  const delSnap = async (id) => { const next = snaps.filter((s) => s.id !== id); setSnaps(next); if (hasStore) { try { await window.storage.set("rbp2_snaps", JSON.stringify(next)); } catch (e) {} } };

  const st = ST[d.status];
  const tabs = [["dash", "לוח בקרה"], ["inputs", "הנתונים שלי"], ["monthly", "תזרים חודשי"], ["after60", "אחרי 60 + מס"], ["rsu", "RSU"], ["track", "מעקב"]];

  return (
    <div className="rbp">
      <style>{STYLES}</style>
      <header className="hero">
        <div className="wrap" style={{ padding: 0 }}>
          <p className="kicker">מתכנן פרישה מוקדמת · תא משפחתי · קופה משותפת</p>
          <h1 className="serif">הגשר שלנו</h1>
          <p className="sub">פרישה מוקדמת אינה שאלה של מספר אחד — אלא של תזרים שנתי, סדר משיכות, מס וסיכון, לאורך כל החיים ולא רק עד 60.</p>
          <div className="verdict-row">
            <div className="verdict"><span className="dot" style={{ background: st.color }} />
              <div><div className="lbl">{st.lbl}</div><div className="val">{st.val}</div></div></div>
            <div className="vfig"><div className="n">{d.surplus >= 0 ? "+" : ""}{fmtK(d.surplus)}</div><div className="c">{d.surplus >= 0 ? "עודף ביטחון" : "חסר לגשר"}</div></div>
            <div className="vfig"><div className="n">{pct(d.bridgeRatio)}</div><div className="c">יחס גשר (כולל כרית)</div></div>
            <div className="vfig"><div className="n">{d.depletedAge ? "גיל " + d.depletedAge : "מחזיק"}</div><div className="c">{d.depletedAge ? "התיק נגמר" : `מספיק עד ${H.planningAge}`}</div></div>
          </div>
          <Bridge d={d} />
        </div>
      </header>

      <main className="wrap">
        <div className="tabs" role="tablist">
          {tabs.map(([id, label]) => <button key={id} className="tab" role="tab" aria-selected={tab === id} onClick={() => setTab(id)}>{label}</button>)}
        </div>

        {tab === "dash" && (
          <div className="grid">
            <div className="card">
              <h3>סטטוס הגשר · עד שכבת ההכנסה הראשונה ({d.bridgeYears} שנים)</h3>
              <div className="grid cols-3">
                <Metric label="פער חודשי נטו" value={fmt(d.monthlyGap)} s="green" note={`${fmt(H.targetMonthly)} − ${fmt(H.passiveMonthly)} פסיבי`} />
                <Metric label="גשר נדרש (כולל כרית)" value={fmt(d.bridgeReqBuf)} s="green" note={`בסיס ${fmt(d.bridgeRequired)} + ${H.safetyBuffer}%`} />
                <Metric label="נכסים נזילים" value={fmt(d.liquidNet)} s="green" note="מזומן + תיקים + RSU נטו" />
              </div>
              <p className="foot">קרן השתלמות ({fmt(d.totStudy)}) ופיצויים אינם בבסיס — מקור לשלב מאוחר/דורש יועץ. הסכומים מאחדים את שני בני הזוג (קופה משותפת); מס מחושב פר-אדם לפי גיל.</p>
            </div>
            <div className="card">
              <h3>מדדי סיכון</h3>
              <div className="grid cols-3">
                <Metric label="יחס גשר (כולל כרית)" value={pct(d.bridgeRatio)} s={statusOf(d.bridgeRatio, 1.25, 1)} note="ירוק 125%+ · צהוב 100% · אדום מתחת" />
                <Metric label="כרית נזילות" value={isFinite(d.cashMonths) ? d.cashMonths.toFixed(0) + " ח'" : "∞"} s={statusOf(d.cashMonths, 24, 12)} note="ירוק 24+ · צהוב 12–24 · אדום מתחת" />
                <Metric label="ריכוזיות RSU" value={pct(d.rsuConc)} s={d.rsuConc < 0.1 ? "green" : d.rsuConc <= 0.25 ? "amber" : "red"} note="ירוק <10% · צהוב 10–25% · אדום 25%+" />
                <Metric label="שיעור משיכה" value={pct(d.withdrawalRate)} s={d.withdrawalRate <= 0.03 ? "green" : d.withdrawalRate <= 0.05 ? "amber" : "red"} note="מהנכסים בשנה" />
                <Metric label="כיסוי פסיבי" value={pct(d.passiveCoverage)} s={d.passiveCoverage >= 0.6 ? "green" : d.passiveCoverage >= 0.4 ? "amber" : "red"} note="מההוצאה, ללא משיכה" />
                <Metric label="עמידות לחץ" value={pct(d.stressRatio)} s={d.resilient ? "green" : statusOf(d.stressRatio, 1, 0.8)} note={`שוק ${H.stressMarketDrop}% · פסיבי ${H.stressPassiveFactor}%`} />
              </div>
            </div>
            <div className="card">
              <h3>התרעות והמלצות</h3>
              {d.alerts.map((a, k) => (
                <div key={k} className={"alert l-" + a.level}>
                  <span className="ai">{a.level === "red" ? "⛔" : a.level === "amber" ? "⚠️" : a.level === "good" ? "✅" : "ℹ️"}</span>
                  <div><p className="at">{a.t}</p><p className="ax">{a.x}</p></div>
                </div>
              ))}
            </div>
          </div>
        )}

        {tab === "inputs" && (
          <div className="grid">
            <div className="card">
              <h3><span className="num">⌂</span>משק בית · קופה משותפת</h3>
              <div className="grid cols-2">
                <Money label="הוצאה חודשית רצויה (נטו)" value={H.targetMonthly} onChange={setHK("targetMonthly")} />
                <Money label="מזומן / קרן כספית (משותף)" value={H.cash} onChange={setHK("cash")} />
                <Money label="הכנסה פסיבית חודשית (נטו)" value={H.passiveMonthly} onChange={setHK("passiveMonthly")} />
                <Num label="אינפלציה" value={H.inflation} onChange={setHK("inflation")} suffix="%" />
                <Num label="תשואה שנתית צפויה (תיק)" value={H.expReturn} onChange={setHK("expReturn")} suffix="%" />
                <Num label="מקדם ביטחון (כרית)" value={H.safetyBuffer} onChange={setHK("safetyBuffer")} suffix="%" />
                <Num label="שנים עד תחילת הפרישה" value={H.planStartYears} onChange={setHK("planStartYears")} suffix="שנים" />
                <Num label="תוחלת תכנון" value={H.planningAge} onChange={setHK("planningAge")} suffix="גיל" />
              </div>
              <div style={{ marginTop: 10 }}><Toggle label="ההכנסה הפסיבית צמודה למדד" value={H.passiveIndexed} onChange={setHK("passiveIndexed")} /></div>
              <div className="grid cols-2" style={{ marginTop: 4 }}>
                <Num label="תרחיש לחץ — ירידת שוק" value={H.stressMarketDrop} onChange={setHK("stressMarketDrop")} suffix="%" />
                <Num label="תרחיש לחץ — הכנסה פסיבית" value={H.stressPassiveFactor} onChange={setHK("stressPassiveFactor")} suffix="%" />
              </div>
            </div>

            {H.people.map((p, idx) => (
              <div className="card" key={idx}>
                <h3><span className="num">{idx + 1}</span>{p.name || "מבוגר " + (idx + 1)}<span className="pill">נכסים פר-אדם (למס)</span></h3>
                <div className="grid cols-2">
                  <Txt label="שם" value={p.name} onChange={setP(idx, "name")} />
                  <Num label="גיל נוכחי" value={p.currentAge} onChange={setP(idx, "currentAge")} suffix="שנים" />
                  <Num label="גיל פרישה מתוכנן" value={p.retirementAge} onChange={setP(idx, "retirementAge")} suffix="שנים" />
                  <Money label="תיק השקעות (שווי)" value={p.portfolio} onChange={setP(idx, "portfolio")} />
                  <Money label="מס משוער אם תמכרי הכל היום" value={p.portfolioTaxOnSale} onChange={setP(idx, "portfolioTaxOnSale")} hint="מהדוח השנתי של בית ההשקעות — חבות מס במימוש מלא" />
                  <Money label="קרן השתלמות" value={p.studyFund} onChange={setP(idx, "studyFund")} />
                  <Num label="גיל נזילות קרן השתלמות" value={p.studyFundLiquidAge} onChange={setP(idx, "studyFundLiquidAge")} suffix="גיל" />
                  <Money label="RSU שהבשיל (ברוטו)" value={p.rsuVestedGross} onChange={setP(idx, "rsuVestedGross")} />
                  <Money label="RSU שטרם הבשיל (צפוי)" value={p.rsuUnvestedExpected} onChange={setP(idx, "rsuUnvestedExpected")} />
                  <Num label="מס משוער על RSU" value={p.rsuTaxRate} onChange={setP(idx, "rsuTaxRate")} suffix="%" />
                  <Money label="קצבת פנסיה צפויה (נטו/חודש)" value={p.pensionNetMonthly} onChange={setP(idx, "pensionNetMonthly")} />
                  <Num label="גיל תחילת קצבת פנסיה" value={p.pensionStartAge} onChange={setP(idx, "pensionStartAge")} suffix="גיל" />
                  <Money label="קצבת אזרח ותיק (חודש)" value={p.allowanceMonthly} onChange={setP(idx, "allowanceMonthly")} />
                  <Num label="גיל תחילת קצבת זקנה" value={p.allowanceStartAge} onChange={setP(idx, "allowanceStartAge")} suffix="גיל" />
                  <Money label="פיצויים (דורש יועץ)" value={p.severance} onChange={setP(idx, "severance")} />
                </div>
              </div>
            ))}
            <div className="card">
              <h3>הכנסות ונכסים נוספים <span className="pill">שדה חופשי + הערה</span></h3>
              <p style={{ fontSize: 13, color: "var(--muted)", marginBottom: 14 }}>הוסיפי כל נכס או הכנסה שלא מופיעים בשדות למעלה — תיק השקעות נוסף, נדל״ן, RSU, החזר הלוואה וכו׳. כל שורה עם תיאור ושווי.</p>
              {(H.extraItems || []).map((item, k) => (
                <div key={item.id} style={{ display: "grid", gridTemplateColumns: "1fr 120px auto", gap: 10, marginBottom: 10, alignItems: "end" }}>
                  <div className="field" style={{ margin: 0 }}>
                    <label>תיאור / הערה</label>
                    <div className="inp"><input type="text" value={item.label} onChange={e => setH(p => ({ ...p, extraItems: p.extraItems.map((x, i) => i === k ? { ...x, label: e.target.value } : x) }))} /></div>
                  </div>
                  <div className="field" style={{ margin: 0 }}>
                    <label>סכום ₪</label>
                    <div className="inp"><input type="number" inputMode="numeric" value={item.amount} onChange={e => setH(p => ({ ...p, extraItems: p.extraItems.map((x, i) => i === k ? { ...x, amount: Number(e.target.value) || 0 } : x) }))} /><span className="suf">₪</span></div>
                  </div>
                  <button className="btn danger" style={{ padding: "10px 12px" }} onClick={() => setH(p => ({ ...p, extraItems: p.extraItems.filter((_, i) => i !== k) }))}>×</button>
                </div>
              ))}
              <button className="btn" onClick={() => setH(p => ({ ...p, extraItems: [...(p.extraItems || []), { id: Date.now(), label: "", amount: 0 }] }))}>+ הוסיפי שורה</button>
              <p className="foot" style={{ marginTop: 10 }}>שדה זה לתיעוד והצגה בלבד. להכנסה פסיבית שוטפת — עדכני את שדה "הכנסה פסיבית חודשית". לתיק השקעות — עדכני את שדה "תיק השקעות" של האדם הרלוונטי.</p>
            </div>
            <div className="card"><div className="row">
              <button className="btn danger" onClick={() => setH(DEFAULTS)}>אפסי לערכי דוגמה</button>
              <span style={{ fontSize: 13, color: "var(--muted)" }}>הנתונים נשמרים אוטומטית ופרטית.</span>
            </div></div>
          </div>
        )}

        {tab === "monthly" && (
          <div className="grid">
            <div className="card">
              <h3>משכורת עצמית · ניהול חודשי</h3>
              <p style={{ marginBottom: 14, color: "#3f4d48", fontSize: 14 }}>הרעיון: לא להחליט כל חודש מאיפה למשוך. דלי המזומן משלם את הפער החודשי ({fmt(d.draw)}), ואחת לתקופה "ממלאים" אותו ממכירת תיק מתוכננת — כך לא נמכרות מניות בלחץ.</p>
              <div className="grid cols-3">
                <Num label="יעד דלי מזומן" value={H.cashBucketMonths} onChange={setHK("cashBucketMonths")} suffix="חודשי פער" />
                <Num label="תדירות מילוי" value={H.refillCadence} onChange={setHK("refillCadence")} suffix="חודשים" />
                <Metric label="גובה דלי היעד" value={fmt(d.bucketTarget)} s="green" note={`${H.cashBucketMonths} × פער חודשי`} />
              </div>
            </div>
            <div className="card">
              <h3>סימולציית 24 חודשים</h3>
              <div style={{ width: "100%", height: 250 }}>
                <ResponsiveContainer>
                  <AreaChart data={d.cashFlow} margin={{ top: 6, right: 6, left: 4, bottom: 0 }}>
                    <defs><linearGradient id="g1" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#b0852f" stopOpacity={0.4} /><stop offset="100%" stopColor="#b0852f" stopOpacity={0.04} /></linearGradient></defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#eef2f0" vertical={false} />
                    <XAxis dataKey="m" tick={{ fontSize: 11, fill: "#5e6f69" }} tickFormatter={(m) => "ח'" + m} />
                    <YAxis tickFormatter={(v) => (v / 1000).toFixed(0) + "k"} tick={{ fontSize: 12, fill: "#5e6f69" }} width={42} />
                    <Tooltip formatter={(v) => fmt(v)} labelFormatter={(m) => "חודש " + m} contentStyle={{ direction: "rtl", borderRadius: 10, border: "1px solid #e3e8e4", fontFamily: "Assistant" }} />
                    <ReferenceLine y={d.draw} stroke="#bf473b" strokeDasharray="4 4" />
                    <Area type="stepAfter" dataKey="bucket" name="יתרת דלי מזומן" stroke="#b0852f" strokeWidth={2.5} fill="url(#g1)" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
              <p className="foot">קפיצות למעלה = אירועי מילוי (מכירת תיק). אומדן מס שנתי על מכירות המילוי: {fmt(d.refillTax)}. כשהיתרה מתקרבת לקו האדום — זה הזמן למלא; ואם השוק יורד מעל 15–20%, עדיף לדחות מכירה ולמשוך מכרית רחבה יותר.</p>
            </div>
          </div>
        )}

        {tab === "after60" && (
          <div className="grid">
            <div className="card">
              <h3>תחזית שנתית · שלבים א'–ד' עם מס</h3>
              <div style={{ width: "100%", height: 270, marginBottom: 14 }}>
                <ResponsiveContainer>
                  <ComposedChart data={d.rows} margin={{ top: 6, right: 6, left: 4, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#eef2f0" vertical={false} />
                    <XAxis dataKey="minAge" tickFormatter={(a) => "גיל " + a} tick={{ fontSize: 11, fill: "#5e6f69" }} />
                    <YAxis tickFormatter={(v) => (v / 1000000).toFixed(1) + "M"} tick={{ fontSize: 12, fill: "#5e6f69" }} width={42} />
                    <Tooltip formatter={(v) => fmt(v)} labelFormatter={(a) => "גיל " + a} contentStyle={{ direction: "rtl", borderRadius: 10, border: "1px solid #e3e8e4", fontFamily: "Assistant", fontSize: 12 }} />
                    <Legend wrapperStyle={{ fontFamily: "Assistant", fontSize: 12 }} />
                    <Bar dataKey="passive" name="פסיבי" stackId="i" fill="#cdb06a" />
                    <Bar dataKey="pension" name="פנסיה" stackId="i" fill="#3f6a86" />
                    <Bar dataKey="allowance" name="קצבת זקנה" stackId="i" fill="#7a9cb0" />
                    <Bar dataKey="fromPort" name="משיכה מהתיק (נטו)" stackId="i" fill="#1d3f38" />
                    <Line type="monotone" dataKey="portEnd" name="יתרת תיק" stroke="#bf473b" strokeWidth={2.5} dot={false} />
                  </ComposedChart>
                </ResponsiveContainer>
              </div>
              <div className="scrollx">
                <table className="tbl">
                  <thead><tr><th>שנה</th><th>גילאים</th><th>שלב</th><th>הוצאות</th><th>פסיבי</th><th>פנסיה</th><th>זקנה</th><th>פער</th><th>מזומן</th><th>קה״ש</th><th>מתיק (נטו)</th><th>מס</th><th>יתרת תיק</th></tr></thead>
                  <tbody>
                    {d.rows.map((r) => (
                      <tr key={r.t} className={r.shortfall ? "dead" : r.allowance > 0 ? "hl" : ""}>
                        <td>{r.year}</td><td>{r.ageLabel}</td><td>{r.phase}</td><td>{fmt(r.expenses)}</td>
                        <td>{fmt(r.passive)}</td><td>{fmt(r.pension)}</td><td>{fmt(r.allowance)}</td><td>{fmt(r.gap)}</td>
                        <td>{fmt(r.fromCash)}</td><td>{fmt(r.fromStudy)}</td><td>{fmt(r.fromPort)}</td><td>{fmt(r.tax)}</td>
                        <td>{r.shortfall ? "נגמר" : fmt(r.portEnd)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <p className="foot">המס הוא <b>אומדן</b>: רווח הון 25%, ומגיל 60 מדרגות מופחתות 10/14/20% אם ההכנסה החייבת מתחת ל-{fmt(TAX2026.over60Ceiling)} (2026). פנסיה מוזנת כנטו (מיסוי פנסיה וקיבוע זכויות — דורשים יועץ). קרן השתלמות וקצבה מקופ״ג להשקעה אחרי 60 — פטורות. אינו תחליף לייעוץ.</p>
            </div>
          </div>
        )}

        {tab === "rsu" && (
          <div className="grid">
            <div className="card">
              <h3>לוח מימוש RSU · החלקת מס</h3>
              <div className="grid cols-2">
                <Num label="פריסה על פני" value={H.rsuSpreadYears} onChange={setHK("rsuSpreadYears")} suffix="שנים" />
                <Toggle label="עדיפות לשנים אחרי גיל 60 (מדרגות מופחתות)" value={H.rsuPreferAfter60} onChange={setHK("rsuPreferAfter60")} />
              </div>
            </div>
            {d.rsuPlans.length === 0 ? (
              <div className="card"><p className="empty">אין RSU שהבשיל בנתונים. הוסיפי "RSU שהבשיל" בלשונית הנתונים כדי לראות לוח מימוש.</p></div>
            ) : d.rsuPlans.map((plan, k) => (
              <div className="card" key={k}>
                <h3>{plan.name} · לוח מוצע</h3>
                <div className="grid cols-3" style={{ marginBottom: 12 }}>
                  <Metric label="מס במכירה חד-פעמית" value={fmt(plan.lumpTax)} s="red" note="אומדן" />
                  <Metric label="מס בפריסה" value={fmt(plan.spreadTax)} s="green" note="אומדן" />
                  <Metric label="חיסכון מס פוטנציאלי" value={fmt(plan.saving)} s={plan.saving > 0 ? "green" : "amber"} note="הפרש" />
                </div>
                <div className="scrollx"><table className="tbl">
                  <thead><tr><th>שנה</th><th>גיל</th><th>מימוש</th><th>מס משוער</th><th>שיעור אפקטיבי</th></tr></thead>
                  <tbody>{plan.sched.map((s, j) => (
                    <tr key={j} className={s.age >= 60 ? "hl" : ""}><td>{s.year}</td><td>{s.age}</td><td>{fmt(s.amount)}</td><td>{fmt(s.tax)}</td><td>{pct(s.rate)}</td></tr>
                  ))}</tbody>
                </table></div>
                <p className="foot">אומדן בהנחת רכיב רווח של ~70% (מסלול 102 הוני). שורות מודגשות = גיל 60+. לאמת מול רו״ח ולבדוק חלונות מסחר לפני מכירה.</p>
              </div>
            ))}
          </div>
        )}

        {tab === "track" && (
          <div className="grid">
            <div className="card">
              <h3>שמירת תמונת מצב</h3>
              <p style={{ marginBottom: 14, fontSize: 14, color: "#3f4d48" }}>שמרי צילום של המצב כדי לעקוב אחרי יחס הגשר לאורך זמן. פרטי ונשמר עבורך בלבד.</p>
              <div className="row"><button className="btn primary" onClick={saveSnap}>שמרי תמונת מצב · {pct(d.bridgeRatio)}</button><span style={{ fontSize: 13, color: "var(--muted)" }}>{snaps.length} שמורות</span></div>
              {!hasStore && <p className="foot">שמירה לטווח ארוך לא זמינה בתצוגה זו — יישמר לסשן הנוכחי בלבד.</p>}
            </div>
            {snaps.length > 0 && (
              <div className="card">
                <h3>יחס הגשר לאורך זמן</h3>
                <div style={{ width: "100%", height: 240 }}>
                  <ResponsiveContainer>
                    <LineChart data={snaps.map((s) => ({ ...s, p: Math.round(s.ratio * 100) }))} margin={{ top: 6, right: 8, left: 4, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#eef2f0" vertical={false} />
                      <XAxis dataKey="date" tick={{ fontSize: 11, fill: "#5e6f69" }} />
                      <YAxis tickFormatter={(v) => v + "%"} tick={{ fontSize: 12, fill: "#5e6f69" }} width={42} domain={[0, "auto"]} />
                      <Tooltip formatter={(v) => v + "%"} contentStyle={{ direction: "rtl", borderRadius: 10, border: "1px solid #e3e8e4", fontFamily: "Assistant" }} />
                      <ReferenceLine y={100} stroke="#bd8814" strokeDasharray="4 4" /><ReferenceLine y={125} stroke="#2e7d5b" strokeDasharray="4 4" />
                      <Line type="monotone" dataKey="p" name="יחס גשר" stroke="#15302b" strokeWidth={2.5} dot={{ r: 4, fill: "#b0852f" }} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>
            )}
            <div className="card">
              <h3>היסטוריה</h3>
              {snaps.length === 0 ? <p className="empty">עדיין אין תמונות מצב.</p> : (
                <div className="scrollx"><table className="tbl">
                  <thead><tr><th>תאריך</th><th>יחס גשר</th><th>זמין</th><th>נדרש</th><th>התיק עד</th><th></th></tr></thead>
                  <tbody>{[...snaps].reverse().map((s) => (
                    <tr key={s.id}><td>{s.date}</td><td><span className={"chip s-" + s.status}>{pct(s.ratio)}</span></td><td>{fmt(s.available)}</td><td>{fmt(s.required)}</td><td>{s.depleted ? "גיל " + s.depleted : "מחזיק"}</td>
                      <td><button className="btn danger" style={{ padding: "5px 12px", fontSize: 13 }} onClick={() => delSnap(s.id)}>מחקי</button></td></tr>
                  ))}</tbody>
                </table></div>
              )}
            </div>
          </div>
        )}

        <p className="thesis">הכלל המרכזי: גשר של ~{d.bridgeYears} שנים שמממן את החצי החסר אחרי ההכנסה הפסיבית, ואז כניסה מדורגת של פנסיה וקצבת זקנה — תוך תזמון מימושי RSU לשנים שאחרי 60 כדי להוריד מס.</p>
        <p className="foot">כלי לחישוב ומעקב בלבד. אומדני המס מבוססים על קבועי 2026 ואינם תחליף לייעוץ מס, פנסיה או השקעות. החלטות על RSU, פיצויים וקיבוע זכויות — עם רו״ח/יועץ פרישה.</p>
      </main>
    </div>
  );
}
